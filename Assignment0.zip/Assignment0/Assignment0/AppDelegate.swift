//
//  AppDelegate.swift
//  Assignment0
//  Hayden Shelton
//  CS 4962
//  Created by u0658884 on 1/24/15.
//  Copyright (c) 2015 u0658884. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var XPos:Float = 0.000
    var YPos:Float = 0.000
    
    var XSlider:UISlider?
    var YSlider:UISlider?
    var YPosLabel:UILabel?
    var XPosLabel:UILabel?
    var MathText:UITextView?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        
        window = UIWindow(frame: UIScreen.mainScreen().bounds)
        
        //unwrap optional to explicit instance
        
        window!.backgroundColor = UIColor.lightGrayColor()
        
        //set up position variables
        var screenWidth = UIScreen.mainScreen().bounds.width
        var screenHeight = UIScreen.mainScreen().bounds.height
        let sliderWidth: CGFloat = screenWidth/1.6
        let sliderHeight: CGFloat = 32
        let XSliderYCoord: CGFloat = screenHeight/2-64
        let XSliderXCoord: CGFloat = screenWidth/6
        let YSliderYCoord: CGFloat = screenHeight/2
        let YSliderXCoord: CGFloat = screenWidth/6
        
        
        
        //place frames on view

        XSlider = UISlider(frame: CGRectMake(XSliderXCoord, XSliderYCoord,  sliderWidth, sliderHeight))
        XSlider!.minimumValue = 0.0
        XSlider!.maximumValue = 1.0
        YSlider = UISlider(frame: CGRectMake(YSliderXCoord, YSliderYCoord, sliderWidth, sliderHeight))
        YSlider!.minimumValue = 0.0
        YSlider!.maximumValue = 1.0
        
        var XLabel = UILabel(frame: CGRectMake(XSliderXCoord-16, XSliderYCoord, 16, sliderHeight)); XLabel.text = "X"
        var YLabel = UILabel(frame: CGRectMake(YSliderXCoord-16, YSliderYCoord, 16, sliderHeight)); YLabel.text = "Y"
        
        XPosLabel = UILabel(frame: CGRectMake(XSliderXCoord+sliderWidth+2, XSliderYCoord, 64, sliderHeight)); XPosLabel!.text = "\(XPos)"
        YPosLabel = UILabel(frame: CGRectMake(YSliderXCoord+sliderWidth+2, YSliderYCoord, 64, sliderHeight)); YPosLabel!.text = "\(YPos)"
        
        MathText = UITextView(frame: CGRectMake(YSliderXCoord, YSliderYCoord+64, sliderWidth, sliderHeight*4))
        MathText!.text="X + Y: 0.000 \nX * Y: 0.000"
        MathText!.backgroundColor = UIColor.lightGrayColor()
        MathText!.textAlignment = NSTextAlignment.Center
        window!.addSubview(XSlider!)
        window!.addSubview(YSlider!)
        window!.addSubview(XLabel)
        window!.addSubview(YLabel)
        window!.addSubview(XPosLabel!)
        window!.addSubview(YPosLabel!)
        window!.addSubview(MathText!)
        
        
        window!.makeKeyAndVisible()
        
        //register event hanlder for sliders
        XSlider!.addTarget(self, action: "sliderChanged", forControlEvents: UIControlEvents.ValueChanged)
        YSlider!.addTarget(self, action: "sliderChanged", forControlEvents: UIControlEvents.ValueChanged)
        
        
        return true
    }
    

    //event hanlder for slider changes
    func sliderChanged()
    {
        
        let val1 = String(format: "%.3f", XSlider!.value)
        let val2 = String(format: "%.3f", YSlider!.value)
        XPosLabel!.text = "\(val1)"
        YPosLabel!.text = "\(val2)"
        
        let sum = XSlider!.value + YSlider!.value
        let prod = XSlider!.value * YSlider!.value
        
        let formatted1 = String(format: "%.4f", sum)
        let formatted2 = String(format: "%.4f", prod)
        
        MathText!.text = "X + Y: \(formatted1) \nX * Y: \(formatted2)"
        
    }
    
 
    

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

