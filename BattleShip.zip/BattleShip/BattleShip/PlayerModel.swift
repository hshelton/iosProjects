//
//  PlayerModel.swift
//  BattleShip
//
//  Created by Hayden Shelton on 2/27/15.
//  Copyright (c) 2015 Hayden Shelton. All rights reserved.
//

import Foundation

class Player
{
    var name: String
  
    
    init()
    {
        name = "Player"
    }
    
}